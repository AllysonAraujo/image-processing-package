# package_name

Description. 
The package image_processing-ally is used to:
	Processing
	    - Histogram matching
	    - Structural similarity
        - Resize image
	Utils:
	    -Reade image
		-Save image
		-Plot image
		-Plot result
		-Plot histogram


## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing-ally

```bash
pip install image_processing-ally
```

## Author
Allyson Araujo

## License
[MIT](https://choosealicense.com/licenses/mit/)